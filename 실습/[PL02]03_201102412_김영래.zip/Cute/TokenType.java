package Cute;

import java.util.HashMap;
import java.util.Map;

public enum TokenType
{
//1) ��ȣ �ȿ� TokenType�� �´� state number �Է�
	INT(1), ID(4), MINUS(2), PLUS(3),
	L_PAREN(5), R_PAREN(6), TRUE(7), FALSE(8),
	TIMES(9), DIV(10), LT(11), GT(12), EQ(13),
	APOSTROPHE(14),
	
	DEFINE(-1), LAMBDA(-1), COND(-1), QUOTE(-1),
	NOT(-1), CAR(-1), CDR(-1), CONS(-1),
	ATOM_Q(-1), NULL_Q(-1), EQ_Q(-1);

	private final int finalState;

	TokenType(int finalState)
	{
		this.finalState = finalState;
	}

	public int getFinalState()
	{
		return finalState;
	}

	public static TokenType keyWordCheck(String str)
	{
		return KeyWord.m.get(str); //if not keyword return null
	}

	private enum KeyWord
	{
		 //2) ���� ���� ������� ������ Ű���� �ۼ�
		DEFINE("define", TokenType.DEFINE),
		LAMBDA("lambda", TokenType.LAMBDA),
		COND("cond", TokenType.COND),
		QUOTE("QUOTE", TokenType.QUOTE),
		NOT("NOT", TokenType.NOT), 
		CAR("CAR", TokenType.CAR), 
		CDR("CDR", TokenType.CDR),
		CONS("CONS", TokenType.CONS),
		ATOM_Q("atom?", TokenType.ATOM_Q), 
		NULL_Q("null?", TokenType.NULL_Q), 
		EQ_Q("eq?", TokenType.EQ_Q);

		final String word;
		final TokenType type;

		KeyWord(String word, TokenType type)
		{
			this.word = word;
			this.type = type;
		}

		private static final Map<String, TokenType> m = new HashMap<String, TokenType>();

		static{
			for(KeyWord k : KeyWord.values())
			{
				m.put(k.word, k.type);
			}
		}
	}
}