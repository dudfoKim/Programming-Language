package Cute15;

import java.io.PrintStream;

public class Printer
{
	PrintStream ps;

	public Printer(PrintStream ps)
	{
		this.ps = ps;
	}
	
	//Make your print class
	//ps.print(...)
	//node.getNext()
	//node.toString() 

	//recursive call or iterate 
	//void printNode
	//void printList
	//�� etc	
	
	public void printNode(Node node)
	{
			ps.print("[" + node.toString() + "] ");
	}

	public void printList(Node node)
	{
		while(node!=null)
		{
			if(node instanceof ListNode)
			{
				ps.print("( ");
				printList(((ListNode)node).value);
				ps.print(") ");
			}
			else if(node instanceof QuoteNode)
			{
				ps.print("\'");
				printList(((QuoteNode)node).value);
				ps.print("");
			}
			else
			{
				printNode(node);
			}
			
			node = node.getNext();
		}
	}
}