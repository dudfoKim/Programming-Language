package Cute15;

public class QuoteNode extends Node
{
	public Node value;
}