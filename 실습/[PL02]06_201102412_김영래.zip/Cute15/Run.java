package Cute15;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Run
{
	private int transM[][];
	private boolean accept[];
	private String source;
	private StringTokenizer st;

	public Run(String source)
	{
		//3) state �� �� ��ŭ �迭 �ʱ�ȭ
		this.transM = new int[16][128];
		this.source = source == null ? "" : source;

		st = new StringTokenizer(source, " ");
		init_TM();
	}

	private void init_TM()
	{
		for (int i = 0; i < transM.length; i++)
		{
			for (int j = 0; j < transM[i].length; j++)
			{
				transM[i][j] = -1;
			}
		}

		int i;

		for (i = '0'; i <= '9'; i++) // digit
		{
			transM[0][i] = 1;
			transM[1][i] = 1; // digit
			transM[2][i] = 1; // '-'
			transM[3][i] = 1; // '+'
			transM[4][i] = 4; // id
		}
		for (i = 'a'; i <= 'z'; i++) // alpha
		{
			transM[0][i] = 4;
			transM[4][i] = 4;
		}
		for (i = 'A'; i <= 'Z'; i++) 
		{
			transM[0][i] = 4;
			transM[4][i] = 4;
		}
		//4) '(', ')', '+', '-', '*', '/', '<', '=', '>', '\'', '#T', '#F', #�� ���ؼ� �۵��ϵ��� �ۼ�
		for(i=0; i<128; i++)
		{
			if(i=='-')
			{
				transM[0][i] = 2;
			}
			if(i=='+')
			{
				transM[0][i] = 3;
			}
			if(i=='(')
			{
				transM[0][i] = 5;
			}
			if(i==')')
			{
				transM[0][i] = 6;
			}
			if(i=='*')
			{
				transM[0][i] = 9;
			}
			if(i=='/')
			{
				transM[0][i] = 10;
			}
			if(i=='<')
			{
				transM[0][i] = 11;
			}
			if(i=='=')
			{
				transM[0][i] = 12;
			}
			if(i=='>')
			{
				transM[0][i] = 13;
			}
			if(i=='\'') 
			{
				transM[0][i] = 15;
			}
			if(i=='#')
			{
				transM[0][i] = 17;
			}
			if(i=='T')
			{
				transM[15][i] = 7;
			}
			if(i=='F')
			{
				transM[15][i] = 8;
			}
			if(i=='?')
			{
				transM[4][i] = 16;
			}
		}
	}
	
	private Token nextToken()
	{
		int StateOld = 0, StateNew = 0;

		if(!st.hasMoreTokens())
		{
			return null;
		}
		// �� ���� ��ū�� ����
		String temp = st.nextToken();
		Token result = null;

		for(int i = 0; i < temp.length(); i++)
		{
			StateNew = transM[StateOld][temp.charAt(i)];

			// �Է¹��ڷ� ���ο� ���� �Ǻ�
			if(StateNew==-1) //5) ������ �ش��ϴ� ������ ����� �׿� �ش��ϴ� �ڵ� �ۼ�
			{
				return null;
			}

			StateOld = StateNew;
		}

		for(TokenType t : TokenType.values())
		{
			if(t.getFinalState()==StateOld)
			{
				TokenType keyWord = TokenType.keyWordCheck(temp);

				if(keyWord!=null)
				{
					result = new Token(keyWord, temp);
				}
				else
				{
					result = new Token(t, temp);
				}
				break;
			}
		}

		return result;
	}

	public List<Token> tokenize()
	{
		// Token ����Ʈ��ȯ
		List<Token> tokens = new ArrayList<Token>();
		Token t = null;

		while (true)
		{
			t = nextToken();
			
			if (t == null)
			{
				break;
			}
			
			tokens.add(t);
		}

		return tokens;
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		//read file...
		FileReader fr = new FileReader("as06.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String source = br.readLine();
		Run s = new Run(source);
		List<Token> tokens = s.tokenize();
		
		BasicParser p = new BasicParser(tokens);
		Node node = p.parseExpr();
		Printer pt = new Printer(System.out);
		pt.printList(node);
	}
}