package Cute15;

public class ListNode extends Node
{
	public Node value;
}