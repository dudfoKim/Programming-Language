package Node;

public abstract class Node
{
	public enum Type
	{
		QUOTED, NOT_QUOTED
	}

	public final Type type;
	Node next;

	public Node(Type type)
	{
		this.type = type;
		this.next = null;
	}

	public void setNext(Node next)
	{
		this.next = next;
	}

	public void setLastNext(Node next)
	{
		if(this.next!=null)
		{
			this.next.setLastNext(next);
		}
		else
		{
			this.next = next;
		}
	}

	public Node getNext()
	{
		return next;
	}

	public class IntNode extends Node
	{
		public final int value;

		public IntNode(Type type, int value)
		{
			super(type);
			this.value = value;
		}

		@Override
		public String toString()
		{
			return "INT: " + Integer.toString(value);
		}
	}

	public class ListNode extends Node
	{
		public final Node value;

		public ListNode(Type type, Node value) 
		{
			super(type);
			this.value = value;
		}
	}
}