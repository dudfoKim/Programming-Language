package Node;

import compile.TreeFactory;
import ast.ListNode;
import ast.Node;
import ast.IntNode;

public class Run
{
	public static int printError()
	{
		System.out.println("Error!");
		
		return -1;
	}

	public static int max(Node node)
	{
		//�ִ밪�� �����ϵ��� �ۼ�
		//value�� next �� �� ū ���� ����
		
		if(node instanceof ListNode)
		{
			if(node.getNext()==null)
			{
				return max(((ListNode) node).value);
			}
			else
			{
				if(max(((ListNode) node).value) > max(node.getNext()))
				{
					return max(((ListNode) node).value);
				}
				else
				{
					return max(node.getNext());
				}
			}
		}
		else if(node instanceof IntNode)
		{
			if(node.getNext()==null)
			{
				return ((IntNode) node).value;
			}
			else
			{
				if(((IntNode) node).value>max(node.getNext()))
				{
					return ((IntNode) node).value;
				}
				else
				{
					return  max(node.getNext());
				}
			}
		}
		else
		{
			return printError();
		}
	}

	public static int sum(Node node)
	{
		//��� value�� ������ ��ȯ
		//value�� next�� �� ���� �����ϸ��
		
		if(node instanceof ListNode)
		{
			if(node.getNext()==null)
			{
				return sum(((ListNode) node).value);
			}
			else
			{
				return sum(((ListNode) node).value) + sum(node.getNext());
			}
		}
		else if(node instanceof IntNode)
		{
			if(node.getNext()==null)
			{
				return ((IntNode) node).value;
			}
			else
			{
				return ((IntNode) node).value + sum(node.getNext());
			}
		}
		else
		{
			return printError();
		}
	}

	public static void main(String[] args)
	{
		// �ش� �̸��� ���Ͽ���
		// "( ( 3 ( ( 10 ) ) 6 ) 4 1 ( ) -2 ( ) )" ���� ��ȣ���� �������
		//���� ����� ����ϵ��� �ۼ�\
		
		System.out.println("========== Example 1 ==========");
		
		String input1 = "( 3 ( 5 2 3 ) -378 )";
		Node node1 = TreeFactory.createtTree(input1);

		System.out.println("Max value : " + max(node1));
		System.out.println("Sum of value : " + sum(node1));
		
		System.out.println("\n========== Example 2 ==========");
		String input2 = "( -4 ( -3 5  -7 ) 10 )";
		Node node2 = TreeFactory.createtTree(input2);
		
		System.out.println("Max value : " + max(node2));
		System.out.println("Sum of value : " + sum(node2));
		
		System.out.println("\n========== Example 3 ==========");
		String input3 = "( . )";
		Node node3 = TreeFactory.createtTree(input3);
		
		System.out.println("Max value : " + max(node3));
		System.out.println("Sum of value : " + sum(node3));
	}
}