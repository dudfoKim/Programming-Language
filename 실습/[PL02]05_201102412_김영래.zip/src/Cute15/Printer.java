package Cute15;

import java.io.PrintStream;

public class Printer
{
	PrintStream ps;

	public Printer(PrintStream ps)
	{
		this.ps = ps;
	}
	
	//Make your print class
	//ps.print(...)
	//node.getNext()
	//node.toString() 

	//recursive call or iterate 
	//void printNode
	//void printList
	//�� etc	
	
	public void printNode(Node node)
	{
		ps.print("[" + node.toString() + "] ");
	}

	public void printList(Node node)
	{
		Node temp = node;

		while(temp!=null)
		{
			if(temp instanceof ListNode)
			{
				ps.print("( ");
				printList(((ListNode)temp).value);
				ps.print(") ");
			}
			else
			{
				printNode(temp);
			}
			
			temp = temp.getNext();
		}
	}
}