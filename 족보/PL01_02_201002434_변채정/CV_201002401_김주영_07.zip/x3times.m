function im3 = x3times( im )
%X3TIMES Summary of this function goes here
%   Detailed explanation goes here
f = imread(im); % image read

[xsize,ysize]= size(f); % get original image size

x3size = xsize*3; % sizex3
y3size = ysize*3;

 %calculate    x = ax'+b
 %      x = 3xa + b  (x = origin image size)
 % (-)  1 =   a + b  ((x=1,x'=1))
 % -----------------
 %    x-1 = (3x-1)a
 %  => a = (x-1)/(3x-1)   and  b = 1 - a
a = (xsize -1) / (x3size -1); 
b = 1- a;

out=zeros(x3size,y3size);  %init zeromatrix

for i = 1:x3size  
    for j = 1:y3size
           % get mu 
        m = (j*a) + (b);   % x = x'a + b
        j2 = floor(m);     % origin image y point
        mu  = m - j2;      % 0 <= mu < 1
           % get lamda
        l = (i*a) + (b);   % x = x'a + b
        i2 = floor(l);     % origin image x point
        lamda=l - i2;      % 0 <= mu < 1
        
         % end of point ( same origin pixel point) 
        if(j == x3size && i == y3size)
            out(j,i) = f(xsize, ysize);
            continue;
        end
         % right points ( only used lamda )
        if(j == x3size)
            out(j,i) = (lamda*(f(xsize, i2)))+((1-lamda)*(f(xsize, i2+1)));
            continue;
        end
         % bottom points ( only used mu)
        if(i == y3size)
            out(j,i) =  (mu*(f(j2,ysize)))+((1-mu)*(f(j2+1,ysize)));
            continue;
        end
        
         % others...
           %  f(x,y') = mu*f(w,y+1)+(1-mu)*f(x,y)
           %  f(x+1,y')=mu*f(x+1,y+1)+(1-mu)*f(x+1,y)
         f1 = (mu*(f(j2,i2+1)))+((1-mu)*f(j2,i2));
         f2 = (mu*(f(j2+1,i2+1)))+((1-mu)*f(j2+1,i2));
           %  f(x',y') = lamda * f(x+1,y') + (1-lamda) * f(x,y')
         out(j,i) = (lamda*f2)+((1-lamda)*f1);
                       
    end
end

im3 = out; %return
%show images
subplot(1,2,1), imshow(uint8(f)), title('original'),
subplot(1,2,2), imshow(uint8(out)), title('x3times')
figure, imshow(uint8(out));
end

